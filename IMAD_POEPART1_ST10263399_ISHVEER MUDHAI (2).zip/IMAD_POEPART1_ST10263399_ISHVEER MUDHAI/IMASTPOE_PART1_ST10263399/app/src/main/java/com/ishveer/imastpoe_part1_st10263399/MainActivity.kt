package com.ishveer.imastpoe_part1_st10263399

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var number1EditText: EditText
    private lateinit var number2EditText: EditText
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1EditText = findViewById(R.id.number1)
        number2EditText = findViewById(R.id.number2)
        resultTextView = findViewById(R.id.resultTextView)

        val addButton = findViewById<Button>(R.id.addButton)
        addButton.setOnClickListener {20
            val number1 = number1EditText.text.toString().toFloat()
            val number2 = number2EditText.text.toString().toFloat()
            val result = number1 + number2
            resultTextView.text = "$number1 + $number2 = $result"
        }

        val subtractButton = findViewById<Button>(R.id.subtractButton)
        subtractButton.setOnClickListener {
            val number1 = number1EditText.text.toString().toFloat()
            val number2 = number2EditText.text.toString().toFloat()
            val result = number1 - number2
            resultTextView.text = "$number1 -$number2 = $result"
        }

        val multiplyButton = findViewById<Button>(R.id.multiplyButton)
        multiplyButton.setOnClickListener{
            val number1 = number1EditText.text.toString().toFloat()
            val number2 = number2EditText.text.toString().toFloat()
            val result = number1 * number2
            resultTextView.text = "$number1 *$number2 = $result"
        }

        val divideButton = findViewById<Button>(R.id.divideButton)
        divideButton.setOnClickListener{
            val number1 = number1EditText.text.toString().toFloat()
            val number2 = number2EditText.text.toString().toFloat()
            val result = number1 / number2
            resultTextView.text = "$number1 /$number2 = $result"
        }


    }}
